#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include<stdio.h>
#include<string.h>
using namespace std;

const int MAXN = 1000000;
string word_exception[MAXN];
string wantedtags[11] = {"vbz", "nn", "jj", "nns", "nnp", "nnps", "vb", "vbd", "vbg", "vbn", "vbp"};
string ans[MAXN][2];
int mrk[MAXN];
string word = "";
int word_cnt = 0;
bool which = 0;
string s1 = "'";
char c = s1[0];

int main(int argc, char* argv[])
{
    /**/
    string s1 = (string)argv[1] + "taggedSentence.txt";
    string s2 = (string)argv[1] + "keywords.txt";
    const char *fileInput = s1.c_str();
    const char *fileOutput = s2.c_str();
    cout << fileInput << ' ' << fileOutput << endl;
    ifstream fin(fileInput);
    ofstream fout(fileOutput);
    ifstream gin("Exceptions.txt");

    int n = 0;
    while (getline(gin, word_exception[n]))
        n++;
    string s;
    getline(fin, s);
    for (int i = 0; i < s.size(); i++)
    {

        if (s[i] == c)
        {
            if (word != "")
            {
                ans[word_cnt][which] = word;
                word_cnt += which;
                which = !which;
                word = "";
            }
        }
        else if (s[i] >= 'a' && s[i] <= 'z')
            word += (char)s[i];
        else if (s[i] >= 'A' && s[i] <= 'Z')
            word += (char)(s[i] - 'A' + 'a');

    }

    for (int i = 0; i < word_cnt; i++)
        for (int j = 0; j < 11; j++)
            if (ans[i][1] == wantedtags[j])
                mrk[i] = 1;
    for(int i = 0; i < word_cnt; i++)
        for (int j = 0; j < n; j++)
            if (ans[i][0] == word_exception[j])
                mrk[i] = 0;
    for (int i = 0; i < word_cnt; i++)
        if ((ans[i][1] == "nn" && ans[i + 1][1] == "pos") && ans[i + 1][0] == "s")
            mrk[i] = 2;
    for (int i = 0; i < word_cnt; i++)
        if (mrk[i] == 1)
            fout << ans[i][0] << endl;
        else if (mrk[i] == 2)
            fout << ans[i][0] << c << ans[i + 1][0] << endl;
    return 0;
    /**/
}
