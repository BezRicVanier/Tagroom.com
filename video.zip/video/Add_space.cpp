#include <iostream>
#include <fstream>

using namespace std;

string s1 = "'";
char c = s1[0];

int32_t main(int argc, char* argv[])
{
    string s1 = (string)argv[1] + "data.txt";
    string s2 = (string)argv[1] + "spaced.txt";
    const char *fileInput = s1.c_str();
    const char *fileOutput = s2.c_str();
    ifstream fin(fileInput);
    ofstream fout(fileOutput);
    string s;
    while(fin >> s) {
        for (int i = 0; i < s.size(); i++)
            if (!(((s[i] <= 'z' && s[i] >= 'a') || (s[i] <= 'Z' && s[i] >= 'A')) || (s[i] <= '9' && s[i] >= '0')) && s[i] != c)
                s[i] = ' ';
        fout << s << endl;
    }
}
