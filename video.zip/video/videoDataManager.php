<?php
	//This code is used to run all the codes associated with analysing the data for a given video, the path of the folder associated with this video file is saved as the 'file_path' key of the session array.
	require_once 'core/init.php';
	$path = Session::get('file_path');
	//$path = 'client_files/client124/video/video1/';
	exec("Add_space.exe {$path}");
	exec('python apple.py ' . $path . 'spaced.txt');
	exec("Keywordmaker.exe {$path}");
	exec("DataAnalyzer.exe <{$path}keywords.txt >{$path}analyzed.txt");
	Session::put('analysed', 1);
	Redirect::to('videoTesting.php');
?>