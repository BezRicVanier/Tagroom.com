#include <stdlib.h>
#include <iostream>
#include <stdio.h>

using namespace std;

int32_t main()
{
    string paths;
    cin >> paths;
    string s1 = "Add_space.exe < " + paths + "/data.txt > " + paths + "/spaced.txt";
    cout << s1  << endl;
    /**/
	system(s1);
	/**/
	system("python apple.py " + paths + "/spacced.txt");
	system("Keywordmaker.exe < " + paths + "/taggedSentence.txt > " + paths + "/keywords.txt");
	system("DataAnalyzer.exe < " + paths + "/keywords.txt > " + paths + "/lastAnalyzed.txt");
	//exec('php addAnalyzed.php {$paths}');
	/**/
}
