#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

const int MAXN = 1000*1000 + 1000;
map <string, int> mp;
int cnt[MAXN];
string words[MAXN];
vector < pair <int, string> > ans;

int32_t main(int argc, char* argv[])
{
    string s1 = (string)argv[1] + "keywords.txt";
    string s2 = (string)argv[1] + "analyzed.txt";
    const char *fileInput = s1.c_str();
    const char *fileOutput = s2.c_str();
    ifstream fin(fileInput);
    ofstream fout(fileOutput);
	string s;
	int num = 0;
	int cnt_tot = 0;
	while (getline(fin, s))
	{
		if (mp.find(s) == mp.end())
        {
            words[num] = s;
			mp[s] = num++;
        }
		cnt_tot++;
		cnt[mp[s]]++;
	}
    for (int i = 0; i < num; i++)
    {
        pair <int, string> mypair;
        mypair.first = cnt[i] * 100 / cnt_tot;
        mypair.second = words[i];
        ans.push_back(mypair);
    }
    sort(ans.begin(), ans.end());
    for (int i = num - 1; i >= 0; i--)
        fout << ans[i].second << ' ' << ans[i].first << " %" << endl;
}
