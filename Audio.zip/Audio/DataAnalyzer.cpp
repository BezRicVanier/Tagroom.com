#include <iostream>
#include <fstream>
#include <map>

using namespace std;

const int MAXN = 1000*1000 + 1000;
map <string, int> mp;
int cnt[MAXN];
string words[MAXN];

int32_t main()
{
	ifstream fin("Keywords.txt");
	ofstream fout("Analyzed.txt");
	string s;
	int num = 0;
	int cnt_tot = 0;
	while (getline(fin, s))
	{
		if (mp.find(s) == mp.end())
			mp[s] = num++;
		cnt_tot++;
		cnt[mp[s]]++;
	}
	for (int i = 0; i < num; i++)
		fout << words[i] << ' ' << cnt[i] / cnt_tot * 100 << " %" << endl;
}