#include <iostream>
#include <fstream>

using namespace std;

const int n = 109583;

int32_t main()
{

	ifstream fin("Dict.txt");
	ofstream fout("dict.h");
	fout << "#include <iostream>\n";
	fout << "#include <fstream>\n";
    fout << "#include <set>\n\n";
    fout << "using namespace std;\n\n";
	fout << "void Add_Dict(set <string> &st) \n";
	fout << "{\n";
	for (int i = 0; i < n; i++)
	{
   		if (i % 10000 == 0)
			cerr << 100 * i / n << '%' << " complete" << '\n';
		string s;
		fin >> s;
		fout  << "    st.insert(" << '"' << s << '"' << ");\n";
	}
	fout << "}\n";
}
