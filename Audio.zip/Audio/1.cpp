//GVSS
//Corse Code: ICS4U
//Assignment 1: Question 1(The Pizza)
//The porpose is to cacluate the amount of time it is going to take to burn the calories for n slices of pizza.

#include <iostream>

using namespace std;

int ans[3] = {0, 0, 0};
/**
This array is going to hold the final answer.
The order is:
ans[0] = Hour
ans[1] = Minute
ans[2] = Second
/**/

const int pizza_cal = 355;
//Calories in 1 slice of Pizza
const int jug_cal = 240;
//Total Calories burned by 1 hour of running
const int time_ratio = 60;
//The ratio between hour and min, and min and sec

void output()
{
	cout << "You will have to jug " << ans[0] << " hours, " << ans[1] << " minutes and " << ans[2] << " seconds" << endl;
}


int32_t main()
{
	//defining and inputing
	int n, total_cal = 0;
	cin >> n;
	
	//calculations
	total_cal = n * pizza_cal;	
	double aloc_time = (double)total_cal / jug_cal;
	/**
	This Value in the loop is going to be:
	i = 0: The total time
	i = 1: The total time after subtracting the hours
	i = 2: the total time after subtracting the hours and the minutes
	/**/
	cerr << aloc_time << endl;
	for (int i = 0; i < 3; i++)
	{
		ans[i] = (int)(aloc_time);
		aloc_time = (aloc_time - (int)aloc_time) * time_ratio;
	}

	output();
	return 0;
}
