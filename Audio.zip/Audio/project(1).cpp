//All rights reserved to Navid Kouchaki Pour
//Course Code: ICS4U
//Teacher: Mr. Sze
#include "dict.h"
#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <queue>
#include <fstream>
#define pb push_back
#define X first
#define Y second
#define Z third

using namespace std;

const int MAXN = 100*1000 + 1000;
const int MAXQ = 10*1000 + 100;
int counter = 0;

struct sentence
{
	int word_cnt;
	vector <string> words;

	void get_inp(string s)
	{
		string ans;
		for (int i = 0; i < s.size(); i++)
		{
			//cerr << ans << endl;
			if (s[i] <= 'z' && s[i] >= 'a')
				ans += s[i];
			else if (s[i] <= 'Z' && s[i] >= 'A')
				ans += 'a' + s[i] - 'A';
			if ((ans.size() > 0 && s[i] == ' ') || ((i == (int)s.size() - 1) && (ans.size() > 0)))
			{
				words.pb(ans);
				ans = "";
			}
		}
		word_cnt = words.size();
	}
};

class Vertex
{
	public:
	vector <Vertex*> adj;
	int cnt_adj;

	Vertex()
	{
		cnt_adj = 0;
		adj.clear();
	}
};

class graph
{
	private:
	int n; //number of total words in our dictionary
	vector <Vertex> vertices[MAXN]; //A vector in which the edges in the graph are saved in. These edges are one directional and their weights are the propability of the first word to be the second one in reality.
	int cnt[MAXN];

	graph()
	{
		n = 0;
		for (int i = 0; i < MAXN; i++)
			cnt[i] = 0;
	}
	////////////////////////////////////////
	public:

	inline void add_edge(Vertex *u, Vertex *b, int prob)
	{
		//u-> adj.pb(v);
	}

	void add_cnt(int v)
	{
	    /**
		int mrk[MAXN];
		for (int i = 0; i < MAXN; i++)
			mrk[i] = 0;
		queue <int> BFS;
		while (!BFS.empty())
		{
			int u = BFS.front();
			for (int i = 0; i < adj[u].size(); i++)
				if (!mrk[adj[u][i]])
					BFS.push(adj[u][i]);
			cnt[u]++;
			mrk[u] = true;
		}
		**/
	}

};

int q; //number of queries, or the number of answers that we have for the voice memo
string arr[MAXQ]; //An array which saves the answers given for the corresponding voice memo
vector <sentence> answers;

void input_answers()
{
	ifstream gin ("Memo_Num.in"); //An input stream to input the answers for the voice memo.
	gin >> q;
	getline(gin, arr[0]); //This is a random line which gets the first endline as input so it doesn't screw up our input.
	for (int i = 0; i < q; i++)
	{
		getline(gin, arr[i]);
		sentence Temp;
		Temp.get_inp(arr[i]);
		answers.pb(Temp);
	}

}

map <string, int> word_num;
map <int, string> num_word;
map <string, int> lang;

int word_to_num(string s)
{
	Add_Dict(lang);
	if (word_num.find(s) != word_num.end())
		return word_num[s];
	if (lang.find(s) == lang.end())
		return -1;
	word_num[s] = counter;
	num_word[counter] = s;
	counter++;
	return word_num[s];
}

string num_to_word(int num)
{
	return num_word[num];
}

int32_t main()
{
	ifstream fin ("alike_words.in"); //An input stream to input the graph of the similar words.
	ofstream fout ("output.out");

	input_answers();
	int mwc = -1; //Maximum word count between all the answers
	for (int i = 0; i < q; i++)
		mwc = max(mwc, answers[i].word_cnt);
	cout << mwc << endl;
	/**/
	for (int i = 0; i < q; i++)
	{
		cerr << i << ":       Number of Words: " << answers[i].word_cnt << "      Words: ";
		for (int j = 0; j < answers[i].word_cnt; j++)
			cerr << '"' <<  answers[i].words[j] << '"' << ' ';
		cerr << endl;
	}
	/**/
	for (int i = 0; i < mwc; i++)
	{
		for (int j = 0; j < q; j++)
			if (answers[j].word_cnt <= i)
			{
	//			graph(
			}
	}
	return 0;
}
