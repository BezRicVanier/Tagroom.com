//All rights reserved to Navid Kouchaki Pour
//Course Code: ICS4U
//Teacher: Mr. Sze
//#include "dict.h"

#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <queue>
#include <fstream>
#define pb push_back
#define X first
#define Y second
#define Z third

using namespace std;

struct sentence
{
	int word_cnt;
	vector <string> words;

	void get_inp(string s)
	{
		string ans;
		for (int i = 0; i < s.size(); i++)
		{
			//cerr << ans << endl;
			if (s[i] <= 'z' && s[i] >= 'a')
				ans += s[i];
			else if (s[i] <= 'Z' && s[i] >= 'A')
				ans += 'a' + s[i] - 'A';
			if ((ans.size() > 0 && s[i] == ' ') || ((i == (int)s.size() - 1) && (ans.size() > 0)))
			{
				words.pb(ans);
				ans = "";
			}
		}
		word_cnt = words.size();
	}
};

class Edge;

/*
Each vertex is defined with 3 int attributes and 1 vector attribute:
1. cnt_out, which is the sum of all the times this word was used in the answers. (The sum of the cnt_used of all edges with *in being this vertex)
2. cnt_ans, which is the total number of times that this word was used till now.
3. tot_prob, which is the probability overall that this word is the answer. This value is defined by the number of times this word was used and the number of times another word was used which had an edge going to this vertex.
*/
class Vertex
{
	public:
	vector <Edge> adj;
	int cnt_out, cnt_ans, tot_prob, index;
	string word;

	Vertex()
	{
		cnt_out = 0;
		cnt_ans = 0;
		tot_prob = 0;
		word = "";
		index = -1;
		adj.clear();
	}
};

/*
Each edge is defined with 4 attributes.
1. *in, which is a pointer to the vertex in the start of the edge.
2. *out, which is a pointer to the vertex in the end of the edge.
3. Prob, which is the probability that the word *in was used but the main answer was *out
4. cnt_used, which is the number of times that is edge has been used.(The number of times that the main answer was the word *out, but a person gave the answer *in instead.
*/
class Edge
{
	public:
	Vertex *in;
	Vertex *out;
	int prob;
	int cnt_used;

	Edge()
	{
		prob = 0;
		cnt_used = 0;
	}
};

/*
A graph
*/
class Graph
{
	/**/
	public:
	int n;
	vector <Vertex> vertices;
	/**/
	void add_vertex()
	{
		struct Vertex temp;
        n++;
		vertices.pb(temp);
	}
	/**
	void add_to_edge(struct Vertex *u, struct Vertex *v) //A function which increases the usage of an edge by 1
	{
		for (int i = 0; i < (u->adj).size(); i++)
			if ((u->adj[i]).out == v)
			{
				Edge edge = u->adj[i];
				edge.cnt_used++;
				u->cnt_out++;
				edge.prob = edge.cnt_used / u->cnt_out;
			}
	}
	/**/
	Graph() // Inputs the values of the previously saved graph into the program
	{
	    /**
        First line is the number of vertexes of the graph.
        Each of the next n line contain the definition of 1 vertex.
        First number, m, is the number of edges going out of the vertex, and the next m triples of numbers are the definitions of each edge
	    /**/
	    //cerr << "FUC" << endl;
	    ifstream graph_in("Graph.txt");
	    int num;
        graph_in >> num;
		for (int i = 0; i < num; i++)
            add_vertex();
		for (int i = 0; i < n; i++)
        {
            int adj_num;
            string s;
            graph_in >> adj_num >> s;
            vertices[i].word = s;
            vertices[i].index = i;
            for (int j = 0; j < adj_num; j++)
            {
                int vert_out, prob, cnt_edge_used;
                graph_in >> vert_out >> prob >> cnt_edge_used;
                Edge new_edge;
                new_edge.in = &vertices[i];
                new_edge.out = &vertices[vert_out];
                new_edge.prob = prob;
                new_edge.cnt_used = cnt_edge_used;
                vertices[i].cnt_out += cnt_edge_used;
                vertices[i].adj.pb(new_edge);
            }
        }
	}
	/**/
	void update_probs(Vertex *v)
	{
	    for (int i = 0; i < (v -> adj).size(); i++)
            (v -> adj[i]).prob = (v -> adj[i]).cnt_used / (v -> cnt_out);
	}
	/**/
	void add_new_edge(Vertex *in, Vertex *out)
	{
        Edge new_edge;
        new_edge.in = in;
        new_edge.out = out;
        new_edge.cnt_used = 1;
        new_edge.prob = 1 / (in -> cnt_out);
	}
	/**/
	void update_graph(Vertex *in, Vertex *out)// A function which upgrades the graph, by adding an edge. Adding this edge means that
	{
        for (int i = 0; i < (in -> adj).size(); i++)
        {
            if ((in -> adj[i]).out == out)
            {
                in -> cnt_out++;
                (in -> adj[i]).cnt_used++;
                update_probs(in);
                return;
            }
        }
        add_new_edge(in, out);
        update_probs(in);
	}
	/**/
	void reset_ans_cnt()//A function which resets the graph to the initial values -> Used for when we're moving from one word in a sentence to the next
	{
	    for (int i = 0; i < vertices.size(); i++)
        {
            vertices[i].cnt_ans = 0;
            vertices[i].tot_prob = 0;
        }
	}
	/**/
	int give_max_prob() //A function which returns the number of the word which is most likely to be the answer for the ith word in the input
	{
	    for (int i = 0; i < n; i++)
            for (int j = 0; j < vertices[i].adj.size(); j++)
            {
                //vertices[i].adj[j].out -> tot_prob += vertices[i].adj[j].out -> cnt_used / vertices[i].cnt_out;
            }
        int max_ans = 0, max_ind = -1;
        for (int i = 0; i < n; i++)
            if (max_ans < vertices[i].cnt_ans)
            {
                max_ans = vertices[i].cnt_ans;
                max_ind = i;
            }
        return max_ind;
	}
	/**/
	void save()
	{
	    /**
	    ofstream fout("graph.txt");
        fout << n << '\n';
	    for (int i = 0; i < n; i++)
        {
            fout << vertices[i].adj.size() << ' ' << vertices[i].word << endl;
            for (int j = 0; j < vertices[i].adj.size(); j++)
            {
                fout << (vertices[i].adj[j].out) -> index << ' ' << vertices[i].adj[j].prob << ' ' << vertices[i].adj[j].cnt_used << endl;
            }
        }
        /**/
	}
};

const int MAXN = 100*1000 + 1000;
const int MAXQ = 10*1000 + 100;
int q; //number of queries, or the number of answers that we have for the voice memo
string arr[MAXQ]; //An array which saves the answers given for the corresponding voice memo
vector <sentence> answers;
int cnt_ans[MAXN];
Graph graph;
map <string, int> word_num;
map <int, string> num_word;
map <string, int> lang;
int counter = 0;

void input_answers(const char *fileInput)
{
    ifstream fin(fileInput);
	ifstream gin ("Memo_Num.txt"); //An input stream to input the answers for the voice memo.
	getline(gin, arr[0]); //This is a random line which gets the first endline as input so it doesn't screw up our input.
    while (getline(gin, arr[q])) {
		sentence Temp;
		Temp.get_inp(arr[q]);
		answers.pb(Temp);
		q++;
	}
	for(int i = 0; i < q; i++)
		cout << arr[i] << endl;
	cout << "HELO" << endl;

}

int word_to_num(string s)
{
	if (word_num.find(s) != word_num.end())
		return word_num[s];

	word_num[s] = graph.n;
	num_word[graph.n] = s;
	graph.add_vertex();
	return word_num[s];
}

string num_to_word(int num)
{
	return num_word[num];
}

int32_t main(int argc, char* argv[])
{
    cout << "FUCK" << endl;
    string s1 = (string)argv[1] + "data.txt";
    string s2 = (string)argv[1] + "output.txt"; //An input stream to input the graph of the similar words.
    const char *fileInput = s1.c_str();
    const char *fileOutput = s2.c_str();
	input_answers(fileInput);
    ofstream fout(fileOutput);
	int mwc = -1; //Maximum word count between all the answers
	for (int i = 0; i < q; i++)
		mwc = max(mwc, answers[i].word_cnt);
	vector <string> final_ans;
	for (int i = 0; i < mwc; i++)
	{
		vector <int> myvec;
		for (int j = 0; j < q; j++)
			if (answers[j].word_cnt > i)
			{
			    int word_num = word_to_num(answers[j].words[i]);
			    if (word_num != -1)
                    graph.vertices[word_num].cnt_ans++;
			}
			else
            {
                int word_num = word_to_num("");
                graph.vertices[word_num].cnt_ans++;
            }
        final_ans.pb(num_to_word(graph.give_max_prob()));
        graph.reset_ans_cnt();
	}
	/**/
	for (int i = 0; i < final_ans.size(); i++)
            fout << final_ans[i] << ' ';
    /**/
    graph.save();
	return 0;
}
